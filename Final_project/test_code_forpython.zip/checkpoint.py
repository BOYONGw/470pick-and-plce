import vrep
import time
import numpy as np

from scipy import linalg


def skew(s):
             
                return [[0 ,-s[2] ,s[1]], [s[2], 0 ,-s[0]],[-s[1] ,s[0], 0]]
        
def skew_S(s):
                A = np.array([[0 ,-s[0][2] ,s[0][1], s[0][3]], [s[0][2], 0 ,-s[0][0], s[0][4]],[-s[0][1] ,s[0][0], 0, s[0][5]],[0,0,0,0]])
                return A
                

# Close all open connections (just in case)
vrep.simxFinish(-1)

# Connect to V-REP (raise exception on failure)
clientID = vrep.simxStart('127.0.0.1', 19997, True, True, 5000, 5)
if clientID == -1:
    raise Exception('Failed connecting to remote API server')

# Get "handle" to the first J of robot
result, J_one_handle = vrep.simxGetObjectHandle(clientID, 'UR5_J1', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J')

# Get "handle" to the second J of robot
result, J_two_handle = vrep.simxGetObjectHandle(clientID, 'UR5_J2', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get second J')
    
# Get "handle" to the third J of robot
result, J_three_handle = vrep.simxGetObjectHandle(clientID, 'UR5_J3', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get third J')
    
# Get "handle" to the fourth J of robot
result, J_four_handle = vrep.simxGetObjectHandle(clientID, 'UR5_J4', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get fourth J')
    
# Get "handle" to the fifth J of robot
result, J_five_handle = vrep.simxGetObjectHandle(clientID, 'UR5_J5', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J')
    
# Get "handle" to the sixth J of robot
result, J_six_handle = vrep.simxGetObjectHandle(clientID, 'UR5_J6', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J')
    
# Get "handle" to the robot
result, robot_handle = vrep.simxGetObjectHandle(clientID, 'UR5_link1_visible', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get robot')
        
# Start simulation
vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot)

# Wait two seconds
time.sleep(2)

# Get the  the first J variable
result, theta = vrep.simxGetJPosition(clientID, J_one_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' first J variable: theta = {:f}'.format(theta))

pret, rJ1 = vrep.simxGetObjectPosition(clientID, J_one_handle,-1, vrep.simx_opmode_oneshot_wait)
print('The position of the first J is {} '.format( rJ1))


#SECOND J


# Get the  the second J variable
result, theta = vrep.simxGetJPosition(clientID, J_two_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get second J variable')
print(' second J variable: theta = {:f}'.format(theta))

pret, rJ2 = vrep.simxGetObjectPosition(clientID, J_two_handle,-1, vrep.simx_opmode_oneshot_wait)
print('The position of the second J is {} '.format( rJ2))


# THIRD J

# Get the  the third J variable
result, theta = vrep.simxGetJPosition(clientID, J_three_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get third J variable')
print(' third J variable: theta = {:f}'.format(theta))

pret, rJ3 = vrep.simxGetObjectPosition(clientID, J_three_handle,-1, vrep.simx_opmode_oneshot_wait)
print('The position of the third J is {} '.format( rJ3))



#FOURTH J

# Get the  the fourth J variable
result, theta = vrep.simxGetJPosition(clientID, J_four_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get fourth J variable')
print(' fourth J variable: theta = {:f}'.format(theta))

pret, rJ4 = vrep.simxGetObjectPosition(clientID, J_four_handle,-1, vrep.simx_opmode_oneshot_wait)
print('The position of the fourth J is {} '.format( rJ4))


#FIFTH J

# Get the  the fifth J variable
result, theta = vrep.simxGetJPosition(clientID, J_five_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get fifth J variable')
print(' fifth J variable: theta = {:f}'.format(theta))

pret, rJ5 = vrep.simxGetObjectPosition(clientID, J_five_handle,-1, vrep.simx_opmode_oneshot_wait)
print('The position of the fifth J is {} '.format( rJ5))


#SIXTH J


# Get the  the sixth J variable
result, theta = vrep.simxGetJPosition(clientID, J_six_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get sixth J variable')
print(' sixth J variable: theta = {:f}'.format(theta))


pret, rJ6 = vrep.simxGetObjectPosition(clientID, J_six_handle,-1, vrep.simx_opmode_oneshot_wait)
print('The position of the sixth J is {} '.format( rJ6))



#END - EFFECTOR

result, end_effector_handle = vrep.simxGetObjectHandle(clientID,'UR5_connection', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get frame')

result, end_effector_pos=vrep.simxGetObjectPosition(clientID,end_effector_handle,J_one_handle,vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get current frame current position')



theta_input = np.array([0.1,0.6,0.7,0.9,0.5,0.6])


q1=[0,0,0.109]
q2=[-0.12,0,0.109]
q3=[-0.12,0,0.353]
q4=[-0.027,0,0.566]
q5=[-0.11,0,0.566]
q6=[-0.11,0,0.649]
q7=[-0.192,0,0.649]

a1 = [0,0,1]
a2 = [-1,0,0]
a3 = [-1,0,0]
a4 = [-1,0,0]
a5 = [0,0,1]
a6 = [-1,0,0]

S1 = [a1,-np.dot(skew(a1),q1)]
S1 = np.reshape(S1,(1,6))
S2 = [a2,-np.dot(skew(a2),q2)]
S2 = np.reshape(S2,(1,6))
S3 = [a3,-np.dot(skew(a3),q3)]
S3 = np.reshape(S3,(1,6))
S4 = [a4,-np.dot(skew(a4),q4)]
S4 = np.reshape(S4,(1,6))
S5 = [a5,-np.dot(skew(a5),q5)]
S5 = np.reshape(S5,(1,6))
S6 = [a6,-np.dot(skew(a6),q6)]
S6 = np.reshape(S6,(1,6))

M=[[0,0,-1,q7[0]],[0,1,0,q7[1]],[1,0,0,q7[2]],[0,0,0,1]]


e1 = linalg.expm(skew_S(S1)*theta_input[0])
e2 = linalg.expm(skew_S(S2)*theta_input[1])
e3 = linalg.expm(skew_S(S3)*theta_input[2])
e4 = linalg.expm(skew_S(S4)*theta_input[3])
e5 = linalg.expm(skew_S(S5)*theta_input[4])
e6 = linalg.expm(skew_S(S6)*theta_input[5])


T = (e1).dot(e2).dot(e3).dot(e4).dot(e5).dot(e6).dot(M)
print(T)


# In[4]:



frame_target_pos = [T[0][3],T[1][3],T[2][3]]
print('Target position:', frame_target_pos)

result, frame_handle = vrep.simxGetObjectHandle(clientID,'ReferenceFrame', vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get frame')

result, current_frame_pos=vrep.simxGetObjectPosition(clientID,frame_handle,robot_handle,vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get current frame current position')
    
print('Position before change:', current_frame_pos)   

result = vrep.simxSetObjectPosition(clientID,frame_handle,robot_handle,frame_target_pos,vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT set frame new position')
    
    
result, current_frame_pos=vrep.simxGetObjectPosition(clientID,frame_handle,robot_handle,vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get current frame current position')
print('Final position:', current_frame_pos) 


# In[5]:


# Set the desired value for each J variable
result, theta = vrep.simxGetJPosition(clientID, J_one_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' first J variable: theta = {:f}'.format(theta))

vrep.simxSetJTargetPosition(clientID, J_one_handle, theta + 0.1, vrep.simx_opmode_oneshot)
time.sleep(2)

result, theta = vrep.simxGetJPosition(clientID, J_one_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' first J variable: theta = {:f}'.format(theta))



result, theta = vrep.simxGetJPosition(clientID, J_two_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' second J variable: theta = {:f}'.format(theta))

vrep.simxSetJTargetPosition(clientID, J_two_handle, 0.6 + theta, vrep.simx_opmode_oneshot)
time.sleep(2)

result, theta = vrep.simxGetJPosition(clientID, J_two_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' second J variable: theta = {:f}'.format(theta))



result, theta = vrep.simxGetJPosition(clientID, J_three_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' third J variable: theta = {:f}'.format(theta))

vrep.simxSetJTargetPosition(clientID, J_three_handle, 0.7 + theta, vrep.simx_opmode_oneshot)
time.sleep(2)

result, theta = vrep.simxGetJPosition(clientID, J_three_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' third J variable: theta = {:f}'.format(theta))


result, theta = vrep.simxGetJPosition(clientID, J_four_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' fourth J variable: theta = {:f}'.format(theta))

vrep.simxSetJTargetPosition(clientID, J_four_handle, 0.9 + theta, vrep.simx_opmode_oneshot)
time.sleep(2)

result, theta = vrep.simxGetJPosition(clientID, J_four_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' fourth J variable: theta = {:f}'.format(theta))


result, theta = vrep.simxGetJPosition(clientID, J_five_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' fifth J variable: theta = {:f}'.format(theta))

vrep.simxSetJTargetPosition(clientID, J_five_handle, 0.5 + theta, vrep.simx_opmode_oneshot)
time.sleep(2)

result, theta = vrep.simxGetJPosition(clientID, J_five_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' fifth J variable: theta = {:f}'.format(theta))


result, theta = vrep.simxGetJPosition(clientID, J_six_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' sixth J variable: theta = {:f}'.format(theta))


vrep.simxSetJTargetPosition(clientID, J_six_handle, 0.6 + theta, vrep.simx_opmode_oneshot)
time.sleep(2)


result, theta = vrep.simxGetJPosition(clientID, J_six_handle, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get first J variable')
print(' sixth J variable: theta = {:f}'.format(theta))


# In[6]:


result, Euler_angles = vrep.simxGetObjectOrientation(clientID,end_effector_handle,robot_handle,vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT get end-effector orientation')
    
print('Final orientation:', Euler_angles)

result =vrep.simxSetObjectOrientation(clientID,frame_handle,robot_handle, Euler_angles, vrep.simx_opmode_blocking)
if result != vrep.simx_return_ok:
    raise Exception('CANT set frame final orientation')



